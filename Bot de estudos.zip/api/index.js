require("dotenv").config();
const express = require("express");
const axios = require("axios");
const cors = require("cors");

const app = express();
app.use(cors());
app.use(express.json());

// 🔑 API KEY interna que o site deve usar
const INTERNAL_KEY = process.env.INTERNAL_KEY;

// 🟦 Token do bot
const BOT_TOKEN = process.env.BOT_TOKEN;

// -------------------------------
// ROTA 1 - LISTAR SERVIDORES DO BOT
// -------------------------------
app.post("/interno/servidores", async (req, res) => {
  try {
    const { key } = req.body;

    if (key !== INTERNAL_KEY) {
      return res.status(403).json({ erro: "API KEY inválida" });
    }

    const result = await axios.get("https://discord.com/api/v10/users/@me/guilds", {
      headers: { Authorization: `Bot ${BOT_TOKEN}` }
    });

    res.json({
      quantidade: result.data.length,
      servidores: result.data
    });

  } catch (err) {
    res.status(500).json({ erro: err.message });
  }
});

// -------------------------------
// ROTA 2 - ENVIAR MENSAGEM EM CANAL
// -------------------------------
app.post("/interno/enviar", async (req, res) => {
  try {
    const { key, canalId, mensagem } = req.body;

    if (key !== INTERNAL_KEY) {
      return res.status(403).json({ erro: "API KEY inválida" });
    }

    const result = await axios.post(
      `https://discord.com/api/v10/channels/${canalId}/messages`,
      { content: mensagem },
      { headers: { Authorization: `Bot ${BOT_TOKEN}` } }
    );

    res.json({ status: "sucesso", data: result.data });

  } catch (err) {
    res.status(500).json({ erro: err.response?.data || err.message });
  }
});


// 🟢 Iniciar API
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log("API interna rodando na porta " + PORT));