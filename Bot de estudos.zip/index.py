import os
import discord
from discord.ext import commands
from discord import app_commands
from google import genai

GEMINI_API_KEY = "AIzaSyDQ71E-fhYLzG1Z1sj8Im2STN9H_pd13FI"
DISCORD_TOKEN = "MTQ0MTA1NDcxMTYyMDA0Mjc2Mw.G7HJc0.PvfxQ9TXtCBIuQASxnHL3sZVuSrO5iGDQ9wvC0"

intents = discord.Intents.default()
intents.message_content = True

bot = commands.Bot(command_prefix="!", intents=intents)

# Cliente Gemini
gemini = genai.Client(api_key=GEMINI_API_KEY)

@bot.event
async def on_ready():
    try:
        synced = await bot.tree.sync()
        print(f"Bot online como {bot.user} | {len(synced)} comandos sincronizados")
    except Exception as e:
        print("Erro ao sincronizar comandos:", e)

# ======================
#     SLASH COMMAND
# ======================
@bot.tree.command(name="gpt", description="Pergunte algo ao Gemini")
async def gpt(interaction: discord.Interaction, pergunta: str):
    await interaction.response.defer()

    try:
        resposta = gemini.models.generate_content(
            model="gemini-2.5-flash",
            contents=pergunta
        )

        await interaction.followup.send(resposta.text)

    except Exception as e:
        await interaction.followup.send(f"❌ Erro: {e}")

bot.run(DISCORD_TOKEN)